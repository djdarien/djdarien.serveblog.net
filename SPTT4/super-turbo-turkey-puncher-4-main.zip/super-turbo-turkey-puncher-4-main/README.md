# super-turbo-turkey-puncher-4
A simple rendition of the classic mini game from the classic Doom 3 game. 
